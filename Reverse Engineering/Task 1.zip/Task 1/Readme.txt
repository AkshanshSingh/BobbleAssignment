Reverse Engineering Assessment 1:

Step 1: Downloaded the apk file from the download link provided in the internship assessment doc file.
Step 2: Decompiled the app using apktool (https://ibotpeaches.github.io/Apktool/). 
        Command used: apktool d Marathi_Keyboard_v4.6.3_apkpure.com.apk
Step 3: Found a .db file (sqlite) present in assets folder. Name of the file: manglish_db.db
Step 4: Used an online sqlite to csv converter (www.rebasedata.com) to convert manglish_db.db file into csv format.
